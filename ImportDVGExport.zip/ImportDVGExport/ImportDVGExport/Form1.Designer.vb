﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnmakedata = New System.Windows.Forms.Button()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.TxtNoRows = New System.Windows.Forms.TextBox()
		Me.btnclearDvg = New System.Windows.Forms.Button()
		Me.btnExportToexcel = New System.Windows.Forms.Button()
		Me.DataGridView1 = New System.Windows.Forms.DataGridView()
		Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
		Me.No = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Name_User = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Country = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.City = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Phone_number = New System.Windows.Forms.DataGridViewTextBoxColumn()
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'btnmakedata
		'
		Me.btnmakedata.Location = New System.Drawing.Point(45, 21)
		Me.btnmakedata.Name = "btnmakedata"
		Me.btnmakedata.Size = New System.Drawing.Size(94, 35)
		Me.btnmakedata.TabIndex = 0
		Me.btnmakedata.Text = "Make Data"
		Me.btnmakedata.UseVisualStyleBackColor = True
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(146, 32)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(94, 13)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = " Number Of Rows:"
		'
		'TxtNoRows
		'
		Me.TxtNoRows.Location = New System.Drawing.Point(246, 29)
		Me.TxtNoRows.Name = "TxtNoRows"
		Me.TxtNoRows.Size = New System.Drawing.Size(100, 20)
		Me.TxtNoRows.TabIndex = 2
		Me.TxtNoRows.Text = "10"
		'
		'btnclearDvg
		'
		Me.btnclearDvg.Location = New System.Drawing.Point(374, 21)
		Me.btnclearDvg.Name = "btnclearDvg"
		Me.btnclearDvg.Size = New System.Drawing.Size(111, 35)
		Me.btnclearDvg.TabIndex = 3
		Me.btnclearDvg.Text = "ClearDVG"
		Me.btnclearDvg.UseVisualStyleBackColor = True
		'
		'btnExportToexcel
		'
		Me.btnExportToexcel.Location = New System.Drawing.Point(502, 21)
		Me.btnExportToexcel.Name = "btnExportToexcel"
		Me.btnExportToexcel.Size = New System.Drawing.Size(119, 35)
		Me.btnExportToexcel.TabIndex = 4
		Me.btnExportToexcel.Text = "Export To Excel"
		Me.btnExportToexcel.UseVisualStyleBackColor = True
		'
		'DataGridView1
		'
		Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
		Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.No, Me.Name_User, Me.Country, Me.City, Me.Phone_number})
		Me.DataGridView1.Location = New System.Drawing.Point(32, 87)
		Me.DataGridView1.Name = "DataGridView1"
		Me.DataGridView1.Size = New System.Drawing.Size(734, 341)
		Me.DataGridView1.TabIndex = 6
		'
		'No
		'
		Me.No.HeaderText = "No"
		Me.No.Name = "No"
		'
		'Name_User
		'
		Me.Name_User.HeaderText = "Name_User"
		Me.Name_User.Name = "Name_User"
		'
		'Country
		'
		Me.Country.HeaderText = "Country"
		Me.Country.Name = "Country"
		'
		'City
		'
		Me.City.HeaderText = "City"
		Me.City.Name = "City"
		'
		'Phone_number
		'
		Me.Phone_number.HeaderText = "Phone_number"
		Me.Phone_number.Name = "Phone_number"
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(800, 450)
		Me.Controls.Add(Me.DataGridView1)
		Me.Controls.Add(Me.btnExportToexcel)
		Me.Controls.Add(Me.btnclearDvg)
		Me.Controls.Add(Me.TxtNoRows)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.btnmakedata)
		Me.Name = "Form1"
		Me.Text = "Form1"
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents btnmakedata As Button
	Friend WithEvents Label1 As Label
	Friend WithEvents TxtNoRows As TextBox
	Friend WithEvents btnclearDvg As Button
	Friend WithEvents btnExportToexcel As Button
	Friend WithEvents DataGridView1 As DataGridView
	Friend WithEvents SaveFileDialog1 As SaveFileDialog
	Friend WithEvents No As DataGridViewTextBoxColumn
	Friend WithEvents Name_User As DataGridViewTextBoxColumn
	Friend WithEvents Country As DataGridViewTextBoxColumn
	Friend WithEvents City As DataGridViewTextBoxColumn
	Friend WithEvents Phone_number As DataGridViewTextBoxColumn
End Class
