﻿Imports System.Linq
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Microsoft.office.Core
Imports Excel = Microsoft.Office.Interop.Excel.XlRangeAutoFormat
Imports Microsoft.Office.Interop
Imports System.IO
Imports System.Xml.XPath
Imports System.Data
Imports System.Xml

Public Class Form1

	Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		Me.CenterToScreen()
	End Sub

	Private Sub TxtNoRows_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNoRows.KeyPress
		If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "+") Then
			MessageBox.Show("Invalid Input! ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
			e.Handled = True
		End If
	End Sub

	Private Sub btncleardata_Click(sender As Object, e As EventArgs) Handles btnmakedata.Click
		If TxtNoRows.Text = "" Then
			MessageBox.Show("Enter The Row Number", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
			Return
		End If
		btnmakedata.Text = "Please Wait.."
		btnmakedata.Enabled = False

		For i As Integer = 1 To TxtNoRows.Text
			With DataGridView1.Rows
				.Add(i, "Users" & i, "Indonesia", "Medan", "061-" & i)
			End With
			btnmakedata.Text = "Make data"
			btnmakedata.Enabled = True

		Next
	End Sub

	Private Sub btnExportToexcel_Click(sender As Object, e As EventArgs) Handles btnExportToexcel.Click
		Try
			btnExportToexcel.Text = "Please Wait.."
			btnExportToexcel.Enabled = False
			SaveFileDialog1.Filter = "Excel Document(*.xlsx | *.xlsx "
			If SaveFileDialog1.ShowDialog = System.Windows.Forms.DialogResult.OK Then
				Dim xlApp As Microsoft.Office.Interop.Excel.Application
				Dim xlworkbook As Microsoft.Office.Interop.Excel.Workbook
				Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
				Dim misValue As Object = System.Reflection.Missing.Value
				Dim i As Integer
				Dim j As Integer

				xlApp = New Microsoft.Office.Interop.Excel.Application
				xlworkbook = xlApp.Workbooks.Add(misValue)
				xlWorkSheet = xlworkbook.Sheets("Sheet1")

				For i = 0 To DataGridView1.RowCount - 2
					For j = 0 To DataGridView1.ColumnCount - 1
						For k As Integer = 1 To DataGridView1.Columns.Count
							xlWorkSheet.Cells(1, k) = DataGridView1.Columns(k - 1).HeaderText
							xlWorkSheet.Cells(i + 2, j + 1) = DataGridView1(j, 1).Value.ToString
						Next
					Next
				Next

				xlWorkSheet.SaveAs(SaveFileDialog1.FileName)
				xlworkbook.Close()
				xlApp.Quit()

				relaseObject(xlApp)
				relaseObject(xlworkbook)
				relaseObject(xlWorkSheet)

				MsgBox("Sucessfully Save..!!")
				btnExportToexcel.Text = "Export To Excel"
				btnExportToexcel.Enabled = True

			End If
		Catch ex As Exception
			MsgBox("Failed To Save..!!")
		End Try
	End Sub

	Private Sub relaseObject(ByVal obj As Object)
		Try
			System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
			obj = Nothing
		Catch ex As Exception
			obj = Nothing
		Finally
			GC.Collect()
		End Try
	End Sub

	Private Sub btnclearDvg_Click(sender As Object, e As EventArgs) Handles btnclearDvg.Click
		DataGridView1.Columns.Clear()
		If DataGridView1.Columns.Count = 0 Then
			With DataGridView1
				.Columns.Clear()
				.Columns.Add("No", "No")
				.Columns.Add("Name_User", "Name_User")
				.Columns.Add("Country", "Country")
				.Columns.Add("City", "City")
				.Columns.Add("Phone_number", "Phone_number")

			End With
		End If
		DataGridView1.DataSource = Nothing
	End Sub
End Class
